# Cal or Ukubot's Child-Friendly Air Strikes

Standalone GitHub Pages app.

## GitHub Pages
Upload the contents of this folder to the root of a GitHub repository, then enable GitHub Pages from the `main` branch and `/ (root)`.
